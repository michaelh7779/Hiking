var ball
var wall = []


function setup() {
  createCanvas(600,600);
  ball = new Circle();
  wall = new Rectangle(30,0);
  
}

function draw() {
  background(220);
  ball.show();
  wall.show();
  fill('black');
  rect(0,200,400,50);
  rect(175,50,150,50);
  rect(300,50,50,150);
  rect(500,0,300,350);
  rect(220,300,100,100);
  rect(100,350,500,125);
  rect(0,210,50,400);
  rect(0,520,600,150);

  if (keyIsPressed) {
    if (keyCode == UP_ARROW) {
      ball.y = ball.y - 2;
      console.log(ball.collision(wall))
      if (ball.collision(wall)){
        ball.y= ball.y+2
      }
    } else if (keyCode == DOWN_ARROW) {
      ball.y = ball.y + 2;
      if (ball.collision(wall)){
        ball.y= ball.y-2;
      }
    } else if (keyCode == LEFT_ARROW) {
      ball.x = ball.x - 2;
      if (ball.collision(wall)){
        ball.y= ball.x+2;
      }
    } else if (keyCode == RIGHT_ARROW) {
      ball.x = ball.x + 2;
      if (ball.collision(wall)){
        ball.y= ball.x-2;
      }
    }

  }


}



//constructor function
function Circle() {
  this.x = 1;
  this.y = 1;
  this.clr = 'red';
  this.diameter = 20;


  this.show = function() {
    push();
    fill(this.clr);
    ellipse(this.x, this.y, this.diameter, this.diameter);
  
    pop();
  }

  this.collision = function(wall) {

    if (this.x + this.diameter / 2 > wall.x &&
      this.x - this.diameter / 2 < wall.x + wall.width &&
      this.y + this.diameter / 2 > wall.y &&
      this.y - this.diameter / 2 < wall.y + wall.height) return true;
    return false;

  }
}

function Rectangle(x,y,width,height) {
  this.x = x;
  this.y = y;
  this.width = 100;
  this.height = 100;

  this.show = function() {
    push();
    fill('black');
    rect(this.x,this.y,this.width,this.height);
    pop();
  }
}

